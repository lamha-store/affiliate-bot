ملف جاهز للنشر على Render. بعد رفع المجلد backend كـ Web Service في Render:
- اضيفي متغيرات Environment في Render: ADMIN_TOKEN, REPORT_EMAIL=lamha1store@gmail.com, ENABLE_PUBLISHING=true (بعد الاختبار), AMAZON keys if available.
- بعد النشر، حدّثي mobile/App.js لضع BACKEND إلى رابط الخدمة.
