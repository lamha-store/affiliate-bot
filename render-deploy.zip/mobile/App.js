import React, {useEffect,useState} from 'react';
import {Text,View,Button,ScrollView} from 'react-native';
export default function App(){
  const [status,setStatus]=useState(null);
  const BACKEND='http://YOUR_BACKEND_URL';
  async function fetchStatus(){ try{ const r=await fetch(BACKEND+'/api/status'); const j=await r.json(); setStatus(j); }catch(e){ setStatus({error:'Cannot reach backend'}); } }
  useEffect(()=>{ fetchStatus(); },[]);
  return (<ScrollView style={{padding:20, marginTop:30}}><Text style={{fontSize:20,fontWeight:'bold'}}>مساعد شخصي</Text><Button title="تحديث" onPress={fetchStatus} /><Text>{status?JSON.stringify(status,null,2):'جارٍ التحميل...'}</Text></ScrollView>);
}
