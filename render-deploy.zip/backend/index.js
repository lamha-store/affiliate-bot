require('dotenv').config();
const express = require('express');
const cron = require('node-cron');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');
const { addUTM } = require('./lib/links');

const PORT = process.env.PORT || 3000;
const app = express();
app.use(express.json());

let logs = [];
function log(msg){ logs.unshift({id:uuidv4(), ts:new Date().toISOString(), msg}); console.log(msg); }

async function fetchTrendingProducts(){
  log('Fetching trending products (mock)...');
  return [
    { id:'P-1001', title:'سماعة بلوتوث ممتازة', price:29.99, source:'amazon', url:'https://www.amazon.com/dp/example1' },
    { id:'P-1002', title:'حقيبة يد نسائية أنيقة', price:45.50, source:'ali', url:'https://www.aliexpress.com/item/example2' }
  ];
}

async function processProduct(product){
  log(`Processing ${product.id}`);
  let affLink = product.url;
  const utm = addUTM(affLink, { source: process.env.UTM_SOURCE||'affiliate-bot', medium: process.env.UTM_MEDIUM||'social', campaign: process.env.UTM_CAMPAIGN||'auto', content: product.id });
  const title = `${product.title} - فرصة مميزة`;
  const description = `اكتشفي ${product.title} بسعر ${product.price}$. الرابط: ${utm}`;
  logs.unshift({ id: uuidv4(), ts: new Date().toISOString(), preparedPost: { title, description, link: utm, product } });
  log('Prepared post: '+title);
}

async function job(){ log('Job started'); try{ const prods = await fetchTrendingProducts(); for(const p of prods){ await processProduct(p); } log('Job done'); }catch(e){ log('Job error: '+e.message); } }

const schedule = process.env.CRON_SCHEDULE || '0 */4 * * *';
cron.schedule(schedule, ()=>{ job(); });

app.get('/api/status',(req,res)=> res.json({ status:'ok', logs: logs.slice(0,50) }));
app.post('/api/run-now', async (req,res)=>{ await job(); res.json({ status:'ok' }); });

app.listen(PORT, ()=> log('Server running on '+PORT));
